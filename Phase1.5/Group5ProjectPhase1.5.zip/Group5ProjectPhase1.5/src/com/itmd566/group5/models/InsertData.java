package com.itmd566.group5.models;

public class InsertData {
	
	public static void main(String[] args) {
		
		DaoModel dao = new DaoModel();
		
		try {
			dao.InsertData();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
