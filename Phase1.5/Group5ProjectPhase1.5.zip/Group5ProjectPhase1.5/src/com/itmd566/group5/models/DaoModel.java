package com.itmd566.group5.models;

import java.sql.SQLException;
import java.sql.Statement;

import com.itmd566.group5.connector.Connector;

public class DaoModel {

	Connector conn = new Connector();
	private Statement statement = null;

	public void InsertData() throws Exception {

		try {

			statement = conn.getConnection().createStatement();

			String sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Customer.xml' INTO TABLE customer ROWS IDENTIFIED BY '<Customer>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Customer\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Comments.xml' INTO TABLE comments ROWS IDENTIFIED BY '<Comment>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Comments\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Employee.xml' INTO TABLE employee ROWS IDENTIFIED BY '<Employee>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Employee\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Expense.xml' INTO TABLE expense ROWS IDENTIFIED BY '<Expense>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Expense\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Invoice.xml' INTO TABLE invoice ROWS IDENTIFIED BY '<Invoice>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Invoice\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Location.xml' INTO TABLE location ROWS IDENTIFIED BY '<Location>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Location\n");
			
			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Orders.xml' INTO TABLE orders ROWS IDENTIFIED BY '<Order>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Orders\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Payment.xml' INTO TABLE payment ROWS IDENTIFIED BY '<Payment>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Payments\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Pricing.xml' INTO TABLE pricing ROWS IDENTIFIED BY '<Pricing>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Pricing\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Transaction.xml' INTO TABLE transaction ROWS IDENTIFIED BY '<Transaction>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Transaction\n");

			sql = "LOAD XML LOCAL INFILE '/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Vehicle.xml' INTO TABLE vehicle ROWS IDENTIFIED BY '<Vehicle>';";
			statement.executeUpdate(sql);
			System.out.println("Inserted Data into Truck\n");

			statement.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

}
