package com.itmd566.group5.domparser;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.itmd566.group5.models.Vehicle;

public class VehicleDomParser {

	public static void main(String[] args) {

		String filepath = "/Users/suryabalarajan/Desktop/SOA/XML_XSD_DTD/Vehicles.xml";
		File xmlFile = new File(filepath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nodeList = doc.getElementsByTagName("Truck");
			List<Vehicle> truList = new ArrayList<Vehicle>();
			for (int i = 0; i < nodeList.getLength(); i++) {
				truList.add(getVehicle(nodeList.item(i)));
			}

			for (Vehicle tru : truList) {
				System.out.println(tru.toString());
			}
		} catch (SAXException | ParserConfigurationException | IOException e1) {
			e1.printStackTrace();
		}

	}

	private static Vehicle getVehicle(Node node) {
		Vehicle tru = new Vehicle();
		if (node.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) node;
			tru.setVehicleNo(getTagValue("VehicleNo", element));
			tru.setMake(getTagValue("Make", element));
			tru.setYear(getTagValue("Year", element));
			tru.setModel(getTagValue("Model", element));
			tru.setLicensePlateNo(getTagValue("LicensePlateNo", element));
			tru.setEmployeeID(getTagValue("EmployeeID", element));
			tru.setColor(getTagValue("Color", element));
			tru.setVIN(getTagValue("VIN", element));
		}

		return tru;
	}

	private static String getTagValue(String tag, Element element) {
		NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
		Node node = (Node) nodeList.item(0);
		return node.getNodeValue();
	}

}
